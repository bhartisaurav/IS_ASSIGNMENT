
# coding: utf-8

# In[195]:


with open('name.txt','r')as f:             #context manager
    f_contents=f.read()
    print(f_contents) 
    
with open('name2.txt','r')as f1:             #context manager
    f_contents1=f1.read()
    print(f_contents1) 
    
with open('name3.txt','r')as f2:             #context manager
    f_contents2=f2.read()
    print(f_contents2) 
            
with open('name4.txt','r')as f3:             #context manager
    f_contents3=f3.read()
    print(f_contents3) 
    
with open('name5.txt','r')as f4:             #context manager
    f_contents4=f4.read()
    print(f_contents4)     


# # INFINITE LOOP

# In[31]:


import re
##regular expression(regex) to detect for loop
pattern=re.compile(r'for\s*\(\s*[a-zA-Z]*\s*[a-zA-Z]\=\d;\s*[a-zA-Z][<=?|>=?]\d*;\s*[a-zA-Z][-|+][-|+|=]\)')
matches=pattern.finditer(f_contents)  #f_contents is a file pointer
for match in matches:              
    print(match)
str2=pattern.findall(f_contents)  #find for loop by matching regex in txt file

for s1 in str2 :
    k=re.findall(r'\d+',s1)       # k hold interger values (as a list) present in for loop by matching regex
    flag=re.findall(r'[-|+][-|+]',s1)  # flag hold either -- or ++   
    k_0=int(k[0])                      #data type conversion
    k_1=int(k[1])
    if k_0<k_1&(flag[0]=='--'):        # matching infinity conditions
        print("malware found!!")
    elif k_0>k_1&(flag[0]=='++'):
        print("malware found!!")   
    
        
    
    

  


# # BUFFER OVERFLOW

# In[21]:


pattern2=re.compile(r'src\[\]\s*\=["][A-Za-z0-9]*["];')  # regex to get username
pattern3=re.compile(r'dest\[\d+\];')                     #regex to get dest size
#matches=pattern2.finditer(f_contents1) 
#matches1=pattern3.finditer(f_contents1) 
#for match in matches:
#    print(match)
#for match in matches1:
#    print(match)
    
str_1=pattern2.findall(f_contents1)                      #find username in file

str_2=re.findall(r'["]\S*["]',str_1[0])                  #get username in a string variable
len_str2=len(str_2[0])-2;                                #store username length

str_3=pattern3.findall(f_contents1)                      #find dest size in file
str_4=re.findall(r'\d+',str_3[0])                        #store dest size in a string variable
if (len_str2 > int(str_4[0])):                           #compare username length with dest size
    print("malware found!!")
 


# # EXCESSIVE MEMORY

# In[22]:



pattern4=re.compile(r'while\(.*\)\{.*\}')                 # regex to detect while loop
#matches=pattern4.finditer(f_contents2) 
#for match in matches:
#    print(match)
    
str_5=pattern4.findall(f_contents2)                      #find while loop in a file
str_6=re.findall(r'\d+',str_5[0])                        # get interger value in a string variable
mem_alloc=int(str_6[0])*int(str_6[1])                    #calc. the size of memory alloc
limit_alloc=9000;                                        #define limit for memory alloc
if limit_alloc<mem_alloc:                               
    print("malware found!!")


#  # OPEN ANONYMOUS WEBSITE

# In[126]:


pattern5=re.compile(r'for\s*\(\s*[a-zA-Z]*\s*[a-zA-Z]\=\d+;\s*[a-zA-Z][<=?|>=?]\d*;\s*[a-zA-Z][-|+][-|+|=]\)\s*[{].*[}]')
str_7=pattern5.findall(f_contents3) 
str_8=re.findall(r'\d+',str_7[0])  # find integer values in for loop

if (re.search(r'system\(\".*\"\)',str_7[0])):  #find system call in for loop
    if int(str_8[1])>1:                        #if system call founded then it is a malware
        print("malware found!!") 




# # TRAPDOOR

# In[240]:


## regex to detect for loop and its contents
pattern6=re.compile(r'for\s*\(\s*[a-zA-Z]*\s*[a-zA-Z]\=\d+;\s*[a-zA-Z][<=?|>=?]\d*;\s*[a-zA-Z][-|+][-|+|=]\)\s*[{].*[}]')
matches=pattern6.finditer(f_contents4) 
str_9=pattern6.findall(f_contents4)                    #find for loop in a file

pattern7=re.compile(r'if\(\s*[A-Za-z][>|<]\d+\s*\|\|\s*[A-Za-z][>|<]\d+\)')  #regex to detect trapdoor cond.
str_10=pattern7.findall(f_contents4)                                         #find trapdoor cond. in a file
#print (str_10[0])
for j in str_10: 
   str_11=re.findall(r'\d+',j)
   #print (str_11[0])
   if ((re.search(r'if\(\s*[A-Za-z][<]\d+\s*\|\|\s*[A-Za-z][>]\d+\)',j))):  # checking different cond. for trapdoor
       if (int(str_11[0])<int(str_11[1])):
            print ("malware found!!")
   if ((re.search(r'if\(\s*[A-Za-z][>]\d+\s*\|\|\s*[A-Za-z][<]\d+\)',j))):
       if int(str_11[0])>int(str_11[1]):
           print ("malware found!!")
       
   

